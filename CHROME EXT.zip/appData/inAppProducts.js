inAppProducts = [];

inAppProducts["color_palette_background"]={sku:"color_palette_background",title:"Palette of 127 background colors",description:''};

inAppProducts["color_background_454f56"]={sku:"color_background_454f56",title:"Background color: grey 1",description:'Color sample: <br><span style="margin-left:5px;display:inline-block;width:150px;height:100px;background-color:#454f56; border-radius:3px;"></span>'};
inAppProducts["color_background_ff7171"]={sku:"color_background_ff7171",title:"Background color: red 1",description:'Color sample: <br><span style="margin-left:5px;display:inline-block;width:150px;height:100px;background-color:#ff7171; border-radius:3px;"></span>'};
inAppProducts["color_background_ff4fc1"]={sku:"color_background_ff4fc1",title:"Background color: pink 1",description:'Color sample: <br><span style="margin-left:5px;display:inline-block;width:150px;height:100px;background-color:#ff4fc1; border-radius:3px;"></span>'};

inAppProducts["speech_recognition"]={sku:"speech_recognition",title:"Speech recognition.",description:'Supportted languages available under'};