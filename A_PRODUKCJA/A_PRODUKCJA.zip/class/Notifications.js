'use strict';

var Notifications = {};