$(function(){
	getAllItems();
})
var getAllItems = function(){
	google.payments.inapp.getSkuDetails({
		'parameters':{'env':'prod'},
		'success':onSkuDetails,
		'failure':onSkuDetailsFail
	})
}
var onSkuDetails = function(sku){
	console.log(sku)
}
var onSkuDetailsFail = function(sku){
	console.log(sku)
}